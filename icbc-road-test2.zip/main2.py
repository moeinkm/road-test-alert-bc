from availability_finder2 import AvailabilityFinder
from email_service2 import EmailService

def main():
    icbc_api_endpoint = 'https://onlinebusiness.icbc.com/deas-api/v1'
    login_headers = {
        'sec-ch-ua-platform': '"Windows"',
        'Cache-control': 'no-cache, no-store',
        'Referer': 'https://onlinebusiness.icbc.com/webdeas-ui/login;type=driver',
        'pragma': 'no-cache',
        'sec-ch-ua': '"Chromium";v="130", "Google Chrome";v="130", "Not?A_Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'Expires': '0',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Content-Type': 'application/json',
    }
    apos_ids = {
        'Port Coquitlam': 73,
        'Burnaby claim center': 274,
        'Burnaby driver licencing': 2,
        'Surrey claim center': 269,
        'Guilford Broadwalk road test center': 11,
        'Surrey Driver Licencing': 281,
        'Newton claim center': 271,
        'North Vancouver driver licencing': 8,
        'Richmond driver licensing ': 93,
        'Vancouver driver licensing': 9,
        'Langley driver licensing': 153,
        'Maple Ridge claim centre': 279,
        'Langley claim centre': 270,
        'Abbotsford driver licensing': 1,
        'Chilliwack driver licensing': 3,
    }

    availability_finder = AvailabilityFinder(icbc_api_endpoint, login_headers, apos_ids)
    available_dates_result = availability_finder.find_available_dates()

    sender_email = 'your-email@gmail.com'
    to_email = 'recipient-email@example.com'
    subject = 'ICBC Road Test Available Dates'

    email_service = EmailService(sender_email, to_email, subject)
    email_service.authenticate()
    raw_decoded_message = email_service.create_message(json.dumps(available_dates_result))
    email_service.send_message(raw_decoded_message)

if __name__ == '__main__':
    main()